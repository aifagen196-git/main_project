import axios from "axios";
import { getSupabase, runCollector } from "./runtime.js";

import linkedinSearches from "../config/linkedinSearches.js";
import normalizeLinkedIn from "../processors/normalizeLinkedIn.js";
import parseLinkedInJob from "../processors/parseLinkedInJob.js";
import extractJobProfile from "../processors/extractJobProfile.js";

const BASE_URL =
  "https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search";

// Lightweight per-job fragment (~26KB, CSS-class HTML) — NOT the 332KB public
// job page. parseLinkedInJob parses this fragment.
const DETAIL_URL = (id) =>
  `https://www.linkedin.com/jobs-guest/jobs/api/jobPosting/${id}`;

const USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36";

// Tunables. LinkedIn's guest endpoint blocks (429) after ~10 pages from one IP,
// so we stay conservative and pace requests.
const PAGE_SIZE = 25; // guest endpoint returns 25 cards per page
const MAX_PAGES = Number(process.env.LINKEDIN_MAX_PAGES || 3);
const LOCATION = process.env.LINKEDIN_LOCATION || "United States";
const SEARCH_DELAY_MS = Number(process.env.LINKEDIN_SEARCH_DELAY_MS || 1500);
const DETAIL_DELAY_MS = Number(process.env.LINKEDIN_DETAIL_DELAY_MS || 800);

const stats = {
  searches: 0,
  rawCards: 0,
  unique: 0,
  detailed: 0,
  saved: 0,
  skipped: 0,
  failed: 0,
};

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

// LinkedIn's guest fragment gives a RELATIVE date ("3 weeks ago", "2 days ago",
// "yesterday"), not a timestamp — inserting it straight into the timestamptz
// `posted_date` column throws. Convert to an approximate ISO date, else null.
function relativeToISO(text = "") {
  const t = String(text).toLowerCase().trim();
  if (!t) return null;
  if (/just now|moments? ago|yesterday/.test(t)) {
    const d = new Date();
    if (t.includes("yesterday")) d.setDate(d.getDate() - 1);
    return d.toISOString();
  }
  const m = t.match(/(\d+)\s*(hour|day|week|month|year)s?\s*ago/);
  if (!m) return null;
  const n = Number(m[1]);
  const unitDays = { hour: 1 / 24, day: 1, week: 7, month: 30, year: 365 }[m[2]];
  return new Date(Date.now() - n * unitDays * 86400000).toISOString();
}

const US_LOCATION =
  /\b(united states|usa|u\.s\.|remote)\b|,\s*(al|ak|az|ar|ca|co|ct|de|fl|ga|hi|id|il|in|ia|ks|ky|la|me|md|ma|mi|mn|ms|mo|mt|ne|nv|nh|nj|nm|ny|nc|nd|oh|ok|or|pa|ri|sc|sd|tn|tx|ut|vt|va|wa|wv|wi|wy)\b/i;

// =============================================
// FETCH FULL JOB DETAILS (per job page)
// =============================================
async function fetchJobDetails(job) {
  try {
    const res = await axios.get(DETAIL_URL(job.source_job_id), {
      headers: { "User-Agent": USER_AGENT },
      timeout: 30000,
    });
    return parseLinkedInJob(res.data); // { description, employmentType, ... } | null
  } catch (err) {
    console.error(`   ❌ details ${job.source_job_id}: ${err.message}`);
    return null;
  }
}

// =============================================
// MAP a detailed LinkedIn job -> jobs-table row
// (same shape the ATS normalizers produce)
// =============================================
async function toRow(job, parsed) {
  const description = parsed?.description || "";
  const profile = await extractJobProfile(description);
  const location = parsed?.location || job.location || "";

  return {
    title: parsed?.title || job.title,
    company: parsed?.company || job.company,
    location,
    employment_type: parsed?.employmentType || "",
    salary: parsed?.salary ? String(parsed.salary) : null,
    description,
    source: "linkedin",
    source_job_id: String(job.source_job_id),
    apply_url: parsed?.applyUrl || job.url,
    posted_date: relativeToISO(parsed?.postedAt),
    skills: profile.skills_required,
    skills_required: profile.skills_required,
    skills_preferred: profile.skills_preferred,
    role_family: profile.role_family,
    min_years: profile.min_years,
    country: profile.country,
    state: profile.state,
    is_remote_us: profile.is_remote_us,
    profile,
    match_score: 0,
    is_active: true,
    last_seen: new Date().toISOString(),
    expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
  };
}

// =============================================
// SAVE (batched upsert)
// =============================================
async function saveJobs(rows) {
  if (!rows.length) return;
  const CHUNK = 500;
  for (let i = 0; i < rows.length; i += CHUNK) {
    const batch = rows.slice(i, i + CHUNK);
    const { error } = await getSupabase()
      .from("jobs")
      .upsert(batch, { onConflict: "source,source_job_id" });
    if (error) {
      stats.failed += batch.length;
      console.error(`❌ batch of ${batch.length} failed: ${error.message}`);
      continue;
    }
    stats.saved += batch.length;
  }
}

// =============================================
// MAIN
// =============================================
export default async function collectLinkedInJobs() {
  console.log("\n==========================================");
  console.log("🔵 LinkedIn Collector Started");
  console.log("==========================================");

  // 1) Search every keyword, collect job cards.
  const cards = [];
  for (const keyword of linkedinSearches) {
    stats.searches++;
    console.log(`\n🔍 ${keyword}`);
    for (let page = 0; page < MAX_PAGES; page++) {
      try {
        const res = await axios.get(BASE_URL, {
          params: { keywords: keyword, location: LOCATION, start: page * PAGE_SIZE },
          headers: { "User-Agent": USER_AGENT },
          timeout: 30000,
        });
        const found = normalizeLinkedIn(res.data).filter((j) => j.source_job_id);
        stats.rawCards += found.length;
        console.log(`   📄 page ${page + 1}: ${found.length} jobs`);
        if (!found.length) break;
        cards.push(...found);
        await delay(SEARCH_DELAY_MS);
      } catch (err) {
        const code = err.response?.status || err.message;
        console.error(`   ⏭️ ${keyword} page ${page + 1}: ${code}`);
        break; // likely a 429 — stop paging this keyword
      }
    }
  }

  // 2) De-duplicate across searches.
  const unique = [...new Map(cards.map((c) => [c.source_job_id, c])).values()];
  stats.unique = unique.length;
  console.log(`\n📦 ${cards.length} cards -> ${unique.length} unique`);

  // 3) Fetch details, normalize, save in batches as we go.
  let batch = [];
  let n = 0;
  for (const job of unique) {
    n++;
    const parsed = await fetchJobDetails(job);
    if (!parsed) {
      stats.failed++;
      await delay(DETAIL_DELAY_MS);
      continue;
    }
    stats.detailed++;

    const loc = parsed.location || job.location || "";
    if (loc && !US_LOCATION.test(loc)) {
      stats.skipped++;
      await delay(DETAIL_DELAY_MS);
      continue;
    }

    batch.push(await toRow(job, parsed));
    if (n % 25 === 0) console.log(`   ...${n}/${unique.length} detailed`);
    if (batch.length >= 100) {
      await saveJobs(batch);
      batch = [];
    }
    await delay(DETAIL_DELAY_MS);
  }
  await saveJobs(batch);

  // 4) Deactivate stale LinkedIn postings not seen recently.
  const staleCutoff = new Date(
    Date.now() - 30 * 24 * 60 * 60 * 1000,
  ).toISOString();
  const { error: deErr, count } = await getSupabase()
    .from("jobs")
    .update({ is_active: false })
    .eq("source", "linkedin")
    .lt("last_seen", staleCutoff)
    .eq("is_active", true)
    .select("id", { count: "exact", head: true });
  if (deErr) console.error(`⚠ Deactivation pass failed: ${deErr.message}`);
  else console.log(`🗑 Deactivated ${count ?? 0} stale LinkedIn jobs`);

  console.log("\n==========================================");
  console.log("✅ LinkedIn Collector Finished");
  console.log("==========================================");
  console.table(stats);
  console.log("==========================================\n");

  return stats;
}

runCollector(import.meta.url, collectLinkedInJobs);
