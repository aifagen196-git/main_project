// tests/testLinkedIn.js
//
// Light end-to-end check of the LinkedIn pipeline WITHOUT writing to the DB:
//   1 search page -> normalizeLinkedIn -> fetch 1 job page -> parseLinkedInJob
//   -> extractJobProfile. Two HTTP calls total. Run: node tests/testLinkedIn.js
import axios from "axios";
import fs from "fs";
import normalizeLinkedIn from "../processors/normalizeLinkedIn.js";
import parseLinkedInJob from "../processors/parseLinkedInJob.js";
import extractJobProfile from "../processors/extractJobProfile.js";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36";
const SEARCH =
  "https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search";

console.log("1) search page…");
const res = await axios.get(SEARCH, {
  params: { keywords: "Data Analyst", location: "United States", start: 0 },
  headers: { "User-Agent": UA },
  timeout: 30000,
});
const cards = normalizeLinkedIn(res.data).filter((j) => j.source_job_id);
console.log(`   ${cards.length} cards, e.g.`, cards[0]?.title, "|", cards[0]?.company);
if (!cards.length) process.exit(1);

console.log("2) job detail page…");
const detail = await axios.get(cards[0].url, {
  headers: { "User-Agent": UA },
  timeout: 30000,
});
fs.writeFileSync("samples/linkedin-sample.html", detail.data);
const parsed = parseLinkedInJob(detail.data);
console.log("   parsed:", {
  title: parsed?.title,
  company: parsed?.company,
  location: parsed?.location,
  employmentType: parsed?.employmentType,
  descChars: parsed?.description?.length,
});

console.log("3) profile extraction…");
const profile = await extractJobProfile(parsed?.description || "");
console.log(
  "   role_family:",
  profile.role_family,
  "| skills:",
  (profile.skills_required || []).length,
  "| min_years:",
  profile.min_years,
);

console.log("\n✅ LinkedIn pipeline OK");
